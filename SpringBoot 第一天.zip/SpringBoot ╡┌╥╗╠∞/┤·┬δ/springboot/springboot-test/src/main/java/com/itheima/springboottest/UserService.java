package com.itheima.springboottest;

import org.springframework.stereotype.Service;

@Service
public class UserService {


    public void add() {
        System.out.println("add...");
    }
}
