package com.itheima.test2;

import com.itheima.test1.Fu;

public class Son extends Fu {
     // 不同包下, 被子类访问
     public void method(){
         // super.show();
         super.print();
     }
}
