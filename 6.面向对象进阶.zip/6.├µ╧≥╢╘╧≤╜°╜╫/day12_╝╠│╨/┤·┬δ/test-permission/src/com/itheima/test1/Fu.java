package com.itheima.test1;

public class Fu {
    void show() {
        System.out.println("默认权限 ---- show方法");
    }

    protected void print() {
        System.out.println("protected权限 ---- print方法");
    }
}
