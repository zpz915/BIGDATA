package com.itheima.test1;

public abstract class Demo extends Animal {

}
