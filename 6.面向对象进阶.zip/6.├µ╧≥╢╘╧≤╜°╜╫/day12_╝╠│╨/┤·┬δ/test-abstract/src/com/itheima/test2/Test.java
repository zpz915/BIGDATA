package com.itheima.test2;

public class Test {
    public static void main(String[] args) {
        Tom t = new Tom();
        t.write();
    }
}
