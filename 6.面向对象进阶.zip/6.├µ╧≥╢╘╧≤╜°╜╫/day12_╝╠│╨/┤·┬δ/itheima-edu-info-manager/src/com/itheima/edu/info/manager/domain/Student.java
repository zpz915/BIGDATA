package com.itheima.edu.info.manager.domain;

public class Student extends Person {
    public Student() {
    }

    public Student(String id, String name, String age, String birthday) {
        super(id, name, age, birthday);
    }
}
