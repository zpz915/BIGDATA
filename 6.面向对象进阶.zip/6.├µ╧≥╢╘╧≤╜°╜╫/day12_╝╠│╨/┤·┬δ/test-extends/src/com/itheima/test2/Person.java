package com.itheima.test2;

public class Person {
    String id;
    String name;
    String age;
    String birthday;
    String address;
}
