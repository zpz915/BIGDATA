package com.itheima.test2;

public class Teacher extends Person {

}
