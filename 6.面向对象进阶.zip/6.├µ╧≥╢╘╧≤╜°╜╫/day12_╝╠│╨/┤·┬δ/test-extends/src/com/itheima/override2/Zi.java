package com.itheima.override2;

public class Zi extends Fu {
    //@Override // 注解: 检查当前的方法是否是一个正确的重写方法
    public static void show() {
        System.out.println("Zi...");
    }

    @Override
    public void method() {
        
    }
}
