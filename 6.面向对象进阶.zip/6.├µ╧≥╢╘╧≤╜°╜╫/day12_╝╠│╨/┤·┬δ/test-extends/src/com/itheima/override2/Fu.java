package com.itheima.override2;

public class Fu {
    public static void show(){
        System.out.println("Fu...");
    }
    void method(){
        System.out.println("Fu...method");
    }
}
