package com.itheima.test3;

public class C extends B{

}
