package com.itheima.test1;

public class Teacher {
    String id;
    String name;
    String age;
    String birthday;
    String address;
}
