package com.itheima.test3;

public class B extends A {
    public void methodB(){
        System.out.println("BBB...类中的method方法");
    }
}
