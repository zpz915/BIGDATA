package com.itheima.test3;

public class TestExtends {
    public static void main(String[] args) {
        C c = new C();
        c.methodA();
        c.methodB();
    }
}
