package com.itheima.test3;

public class A {
    public void methodA(){
        System.out.println("AAA..类中的method方法");
    }
}
