package com.itheima.test4;

public class Fu {
    int a = 10;
}
