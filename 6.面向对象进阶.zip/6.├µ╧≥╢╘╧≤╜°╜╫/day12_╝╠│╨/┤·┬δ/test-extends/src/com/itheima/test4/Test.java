package com.itheima.test4;

public class Test {
    public static void main(String[] args) {
        Zi z = new Zi();
        z.method();
    }
}
