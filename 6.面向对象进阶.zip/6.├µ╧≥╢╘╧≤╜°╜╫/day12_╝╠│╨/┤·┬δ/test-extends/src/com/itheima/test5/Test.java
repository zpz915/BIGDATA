package com.itheima.test5;

public class Test {
    public static void main(String[] args) {
        Zi z = new Zi();
        z.method();
    }
}
