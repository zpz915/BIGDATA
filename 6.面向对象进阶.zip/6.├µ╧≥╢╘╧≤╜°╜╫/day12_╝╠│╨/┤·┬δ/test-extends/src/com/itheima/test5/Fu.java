package com.itheima.test5;

public class Fu {
    public void show(){
        System.out.println("父类show方法");
    }
}
