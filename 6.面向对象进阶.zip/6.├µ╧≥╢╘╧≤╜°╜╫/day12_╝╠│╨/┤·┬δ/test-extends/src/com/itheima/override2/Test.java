package com.itheima.override2;

public class Test {
    public static void main(String[] args) {
        Zi z = new Zi();
        z.show();
    }
}
