package com.itheima.test7;

/*
    接口实现类
 */
public class InterImpl implements InterC {

    @Override
    public void showA() {

    }

    @Override
    public void showB() {

    }
}
