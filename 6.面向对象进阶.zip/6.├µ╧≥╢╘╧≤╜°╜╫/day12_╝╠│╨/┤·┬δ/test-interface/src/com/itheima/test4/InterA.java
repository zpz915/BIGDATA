package com.itheima.test4;

public interface InterA {

    public static void show(){
        System.out.println("InterA...show");
    }
}
