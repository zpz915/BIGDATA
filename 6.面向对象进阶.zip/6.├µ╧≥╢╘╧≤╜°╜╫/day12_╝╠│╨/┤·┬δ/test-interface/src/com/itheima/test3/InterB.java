package com.itheima.test3;

public interface InterB {
    public default void show(){
        System.out.println("B....show方法");
    }
}
