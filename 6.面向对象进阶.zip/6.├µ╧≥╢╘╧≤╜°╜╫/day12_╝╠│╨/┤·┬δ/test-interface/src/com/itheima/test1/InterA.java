package com.itheima.test1;

public interface InterA {
    public abstract void print1();
    public abstract void print2();
    public abstract void study();
}
