package com.itheima.test2;

public interface Inter {
    public static final int NUM = 10;

    // public Inter(){}

    public abstract void show();
}
