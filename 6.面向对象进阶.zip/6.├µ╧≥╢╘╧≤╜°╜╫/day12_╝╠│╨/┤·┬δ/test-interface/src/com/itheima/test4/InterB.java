package com.itheima.test4;

public interface InterB {

    public static void show(){
        System.out.println("InterB...show");
    }
}
