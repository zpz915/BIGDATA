package com.itheima.test1;

public interface Inter {
    public abstract void study();
}
