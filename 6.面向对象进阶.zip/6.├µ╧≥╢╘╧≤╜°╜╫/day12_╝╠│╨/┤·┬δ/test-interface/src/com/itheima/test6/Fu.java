package com.itheima.test6;

public class Fu {
    public void show(){
        System.out.println("Fu...show");
    }
}
