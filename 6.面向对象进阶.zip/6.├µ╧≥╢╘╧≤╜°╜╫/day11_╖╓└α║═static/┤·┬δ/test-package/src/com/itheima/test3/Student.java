package com.itheima.test3;

public class Student {
}
