package com.itheima.test2;

public class Student {
}
