package com.itheima.edu.info.manager.domain;

public class Teacher extends Person{

}
