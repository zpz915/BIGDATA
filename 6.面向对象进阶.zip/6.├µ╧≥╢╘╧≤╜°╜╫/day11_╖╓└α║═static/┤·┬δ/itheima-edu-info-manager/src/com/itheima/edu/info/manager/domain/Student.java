package com.itheima.edu.info.manager.domain;

public class Student extends Person{

}
