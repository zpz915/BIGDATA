package com.itheima.domain;

public class User {
}
